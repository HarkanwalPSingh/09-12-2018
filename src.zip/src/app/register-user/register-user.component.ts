import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import {ActivatedRoute,Router} from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {

  pageTitle: string = "Create a new account today"
  pageDescription: string ="It's free and always will be!"
  successMessage:string
  errorMessage:string

  constructor(private router:Router,private userService : UserService) { }

  ngOnInit() {
  }

  // _firstName:string
  // _lastName:string
  // _dob:string
  // _emailId:string
  // _gender:string
  // _password:string
  // _user:User
  // get firstName():string{
  //   return this._firstName
  // }

  // set firstName(value:string){
  //   this._firstName=value
  // }

  // get lastName():string{
  //   return this._lastName
  // }

  // set lastName(value:string){
  //   this._lastName=value
  // }

  // get dob():string{
  //   return this._dob
  // }

  // set dob(value:string){
  //   this.dob=value
  // }

  // get emailId():string{
  //   return this._emailId
  // }

  // set emailId(value:string){
  //   this.emailId=value
  // }

  // get gender():string{
  //   return this._gender
  // }

  // set gender(value:string){
  //   this.gender=value
  // }

  // get password():string{
  //   return this._password
  // }

  // set password(value:string){
  //   this.password=value
  // }

  onSubmit(user:User){
    // this._user={
    //   firstName:this._firstName,
    //   lastName:this.lastName,
    //  dob:this._dob,
    //  emailId:this._emailId,
    //  password:this._password,
    //  gender:this._gender
    // }


    this.userService.registerUser(user).subscribe(
      message=>{
        console.log(message)
        console.log("Registered Successfully");
      },
      message=>{
        this.errorMessage=message
        console.log("User not Registered");
        
      }
    )
    this.router.navigate(['/login'])
  }
}