import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl, Validators, FormBuilder} from '@angular/forms';
import {FileUploader} from 'ng2-file-upload';
import {FileLikeObject} from "ng2-file-upload/file-upload/file-like-object.class";
import {FileSelectDirective, FileDropDirective} from 'ng2-file-upload';
import {environment} from '../../environments/environment';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css'],
  providers: [FileSelectDirective, FileDropDirective]
})
export class UserProfileComponent implements OnInit {

   // public user: User;
  
  //  public typeUpload: string;
  //  public uploader: FileUploader = new FileUploader({
  //    url: `${environment.url}/api/profile/updatePhoto`,
  //    maxFileSize: 1 * 1024 * 1024,
  //    allowedMimeType: ['image/png', 'image/jpg', 'image/gif', 'image/jpeg']
  //  });
  constructor() { }


  ngOnInit() {
    // this.uploader.authToken = 'Bearer ' + localStorage.token;
    // this.fileUploader();
  }

  // private fileUploader() {
  //   this.uploader.onWhenAddingFileFailed = (item: FileLikeObject, filter: any, options: any) => {
  //     console.log(item, filter, options)
  //     if (item.size > options.maxFileSize) {
  //       this.toastyService.info({
  //         title: 'Too BiG ! ',
  //         msg: 'This File is too BIG, please upload a file that do not exceed 1 mb'
  //       })
  //     }
  //   };
  //   this.uploader.onBuildItemForm = (item: any, form) => {
  //     form.append('userId', this.auth.user['_id']);
  //     form.append('uploadType', this.typeUpload);

  //   };
  //   this.uploader.onAfterAddingFile = (file: any) => {
  //     file.withCredentials = false;
  //     file.typeUpload = this.typeUpload;
  //   };
  //   this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
  //     this.auth.callRefreshUserData(JSON.parse(response));
  //   };

    //  getTypeUpload(event) {
    //   return this.typeUpload = event.target.id;
    // }

}
