import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout-user',
  templateUrl: './logout-user.component.html',
  styleUrls: ['./logout-user.component.css']
})
export class LogoutUserComponent implements OnInit {
  user:User
  constructor(private router : Router) { }

  ngOnInit() {
    this.user=JSON.parse(localStorage.getItem("user"))
    if(this.user){
      localStorage.removeItem("user")
      this.router.navigate(['/welcome'])
    }
    else{
      this.router.navigate(['/welcome'])
    }
  }
}