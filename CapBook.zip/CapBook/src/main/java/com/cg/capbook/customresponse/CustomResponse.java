package com.cg.capbook.customresponse;

public class CustomResponse {
	private int statusCode;
	private String responseMessage;
	public CustomResponse() {}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public CustomResponse(int statusCode, String responseMessage) {
		super();
		this.statusCode = statusCode;
		this.responseMessage = responseMessage;
	}
	public CustomResponse(int statusCode, Throwable responseMessage) {
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((responseMessage == null) ? 0 : responseMessage.hashCode());
		result = prime * result + statusCode;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomResponse other = (CustomResponse) obj;
		if (responseMessage == null) {
			if (other.responseMessage != null)
				return false;
		} else if (!responseMessage.equals(other.responseMessage))
			return false;
		if (statusCode != other.statusCode)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "CustomResponse [statusCode=" + statusCode + ", responseMessage=" + responseMessage + "]";
	}
}